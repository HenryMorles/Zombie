#pragma once
#ifndef ENEMY_CLASS_H
#define ENEMY_CLASS_H
class Enemy_Class {
public:
	int hp;
	int x;
	int y;
	bool dead;
	int speed;
};
#endif