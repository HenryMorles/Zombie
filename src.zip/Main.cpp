#include "Header/Game.h"
using namespace std;


int main() {
	Game game;
	game.Start();
	return 0;
}